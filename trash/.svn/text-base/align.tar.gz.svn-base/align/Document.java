import java.util.Vector;

public class Document {
	
	public Document() {
		hardRegionTable = new Vector<HardRegion>();
	}
	
	public Vector<HardRegion> getHardRegionTable() {
		return hardRegionTable;
	}
	
	public void addHardRegion(HardRegion hardRegion) {
		hardRegionTable.add(hardRegion);
	}
	
	private Vector<HardRegion> hardRegionTable;
	
}
