import junit.framework.TestCase;

public class AlignerTest extends TestCase {
	
	public static final float PART = 0.6f;

	public AlignerTest() {
		aligner = Aligner.getInstance();
		xDocument = createXDocument();
		yDocument = createYDocument();
	}
	
	public void testAlign() {
		DocumentAlignment documentAlignment = 
			aligner.align(xDocument, yDocument);
		//System.out.println(documentAlignment);
		assertEquals(2, documentAlignment.getHardRegionAlignmentTable().size());
		HardRegionAlignment hardRegionAlignment0 = 
			documentAlignment.getHardRegionAlignmentTable().get(0);
		assertEquals(2, 
				hardRegionAlignment0.getSoftRegionAlignmentTable().size());
		SoftRegionAlignment softRegionAlignment00 = 
			hardRegionAlignment0.getSoftRegionAlignmentTable().get(0);
		assertEquals(1, softRegionAlignment00.getDeltaX());
		assertEquals(2, softRegionAlignment00.getDeltaY());
		SoftRegionAlignment softRegionAlignment01 = 
			hardRegionAlignment0.getSoftRegionAlignmentTable().get(1);
		assertEquals(1, softRegionAlignment01.getDeltaX());
		assertEquals(1, softRegionAlignment01.getDeltaY());
		HardRegionAlignment hardRegionAlignment1 = 
			documentAlignment.getHardRegionAlignmentTable().get(1);
		assertEquals(1, 
				hardRegionAlignment1.getSoftRegionAlignmentTable().size());
		SoftRegionAlignment softRegionAlignment10 = 
			hardRegionAlignment1.getSoftRegionAlignmentTable().get(0);
		assertEquals(1, softRegionAlignment10.getDeltaX());
		assertEquals(1, softRegionAlignment10.getDeltaY());
	}
	
	public void testFilter() {
		DocumentAlignment alignment = 
			aligner.align(xDocument, yDocument);
		int nrAlignments = countAlignments(alignment);

		DocumentAlignment filteredAlignment = aligner.filter(alignment, 1.0f);
		int nrFilteredAlignments = countAlignments(filteredAlignment);
		assertEquals(nrAlignments, nrFilteredAlignments);

		filteredAlignment = aligner.filter(alignment, 0.0f);
		nrFilteredAlignments = countAlignments(filteredAlignment);
		assertEquals(0, nrFilteredAlignments);

		filteredAlignment = aligner.filter(alignment, PART);
		nrFilteredAlignments = countAlignments(filteredAlignment);
		assertEquals((float)nrAlignments * PART, (float)nrFilteredAlignments, 
				0.5f);
	}
	
	private Document createXDocument() {
		Document document = new Document();
		HardRegion hardRegion0 = new HardRegion();
		SoftRegion softRegion00 = new SoftRegion();
		softRegion00.addString("very long sentence indeed");
		SoftRegion softRegion01 = new SoftRegion();
		softRegion01.addString("medium sentemce");
		hardRegion0.addSoftRegion(softRegion00);
		hardRegion0.addSoftRegion(softRegion01);
		document.addHardRegion(hardRegion0);
		HardRegion hardRegion1 = new HardRegion();
		SoftRegion softRegion10 = new SoftRegion();
		softRegion10.addString("aaa");
		hardRegion1.addSoftRegion(softRegion10);
		document.addHardRegion(hardRegion1);
		return document;
	}

	private Document createYDocument() {
		Document document = new Document();
		HardRegion hardRegion0 = new HardRegion();
		SoftRegion softRegion00 = new SoftRegion();
		softRegion00.addString("short 1");
		SoftRegion softRegion01 = new SoftRegion();
		softRegion01.addString("short 2");
		SoftRegion softRegion02 = new SoftRegion();
		softRegion02.addString("another medium");
		hardRegion0.addSoftRegion(softRegion00);
		hardRegion0.addSoftRegion(softRegion01);
		hardRegion0.addSoftRegion(softRegion02);
		document.addHardRegion(hardRegion0);
		HardRegion hardRegion1 = new HardRegion();
		SoftRegion softRegion10 = new SoftRegion();
		softRegion10.addString("bbb");
		hardRegion1.addSoftRegion(softRegion10);
		document.addHardRegion(hardRegion1);
		return document;
	}
	
	private int countAlignments(DocumentAlignment alignment) {
		int count = 0; 
		for (HardRegionAlignment hardRegionAlignment : 
			alignment.getHardRegionAlignmentTable()) {
			count += hardRegionAlignment.getSoftRegionAlignmentTable().size();
		}
		return count;
	}

	private Aligner aligner;
	private Document xDocument, yDocument;
	
}
