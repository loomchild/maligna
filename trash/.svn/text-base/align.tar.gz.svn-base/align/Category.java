import java.util.LinkedList;
import java.util.List;

public class Category {
	
	public static final float PARAMETER_C = 1.0f;
	public static final float PARAMETER_S_SQUARE = 6.8f;
	public static final float BIG_DISTANCE = 25.0f;

	public Category(int deltaX, int deltaY, float probability) {
		this.deltaX = deltaX;
		this.deltaY = deltaY;
		this.penalty = calculatePenalty(probability);
	}
	
	public int getDeltaX() {
		return deltaX;
	}
	
	public int getDeltaY() {
		return deltaY;
	}

	public float calculateDistance(int x, int y, 
			HardRegion xRegion, HardRegion yRegion) {
		if ((x < deltaX) || (y < deltaY)) {
			return Float.POSITIVE_INFINITY;
		} else {
			int xLength = calculateLength(xRegion, x - deltaX, x - 1); 
			int yLength = calculateLength(yRegion, y - deltaY, y - 1); 
			return match(xLength, yLength) + penalty;
		}
	}
	
	public float calculatePreviousDistance(int x, int y,
			SoftRegionAlignment[][] alignmentTable) {
		if ((x < deltaX) || (y < deltaY)) {
			return 0.0f;
		} else {
			return alignmentTable[x - deltaX][y - deltaY].getTotalDistance();
		}
	}
	
	public List<SoftRegion> createXRegionList(int x, HardRegion xRegion) {
		return createRegionList(xRegion, x - deltaX, x - 1);
	}

	public List<SoftRegion> createYRegionList(int y, HardRegion yRegion) {
		return createRegionList(yRegion, y - deltaY, y - 1);
	}
	
	private List<SoftRegion> createRegionList(HardRegion hardRegion, 
			int begin, int end) {
		List<SoftRegion> regionList = new LinkedList<SoftRegion>();
		for (int regionNr = begin; regionNr <= end; ++regionNr) {
			regionList.add(hardRegion.getSoftRegionTable().get(regionNr));
		}
		return regionList;		
	}
	
	private int calculateLength(HardRegion hardRegion, 
			int begin, int end) {
		int length = 0;
		for (int regionNr = begin; regionNr <= end; ++regionNr) {
			length += hardRegion.getSoftRegionTable().get(regionNr).getLength();
		}
		return length;
	}
	
	private float match(int xLength, int yLength) {
		if (xLength == 0 && yLength == 0) {
			return 0.0f;
		} else {
			double mean = (xLength + yLength / PARAMETER_C) / 2.0f;
			double z = Math.abs((PARAMETER_C * xLength - yLength) / 
					Math.sqrt(PARAMETER_S_SQUARE * mean));
			double pd = 2.0 * (1.0 - pnorm(z));
			if (pd > 0.0) {
				return (float)-Math.log(pd);
			} else {
				return BIG_DISTANCE;
			}
		}
	}
	
	private double pnorm(double z) {
		double t = 1.0 / (1.0 + 0.2316419 * z);
		double pd = 1.0 - 0.3989423 * Math.exp(-z * z / 2.0) *
			((((1.330274429 * t - 1.821255978) * t
					+ 1.781477937) * t - 0.356563782) * t + 0.319381530) * t;
		return pd;
	}
	
	private float calculatePenalty(float probability) {
		return (float)-Math.log(probability);
	}
	
	private int deltaX, deltaY;

	private float penalty;

}
