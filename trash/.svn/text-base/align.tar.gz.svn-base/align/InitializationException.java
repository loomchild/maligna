
public class InitializationException extends RuntimeException {

	private static final long serialVersionUID = 10L;
	
	public InitializationException(String message) {
		super(message);
	}

	
}
