import java.io.IOException;

import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

public class Parser {

	public static Parser getInstance() {
		return instance;
	}

	public Document parse(String fileName, String hardTag, String softTag) 
			throws SAXException, IOException {
		ParserHandler handler = 
			new ParserHandler(hardTag, softTag);
		parser.setContentHandler(handler);
		parser.parse(fileName);
		return handler.getDocument();
	}
	
	private Parser() {
		try {
			parser = XMLReaderFactory.createXMLReader();
		} catch (SAXException e) {
			throw new InitializationException("Cannot crete XML parser: " 
					+ e.getMessage());
		}
	}
	
	private static Parser instance = new Parser();
	
	private XMLReader parser;
	
}
