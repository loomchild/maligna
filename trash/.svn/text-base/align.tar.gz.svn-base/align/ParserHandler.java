import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;

public class ParserHandler implements ContentHandler {
	
	public ParserHandler(String hardTag, String softTag) {
		this.hardTag = hardTag;
		this.softTag = softTag;
	}

	public void setDocumentLocator(Locator locator) {
	}

	public void startDocument() throws SAXException {
		element = Element.NONE;
		document = new Document();
	}

	public void endDocument() throws SAXException {
	}

	public void startPrefixMapping(String prefix, String uri)
			throws SAXException {
	}

	public void endPrefixMapping(String prefix) throws SAXException {
	}

	public void startElement(String uri, String localName, String qName,
			Attributes atts) throws SAXException {
		if (localName.equals(hardTag)) {
			element = Element.HARD;
			hardRegion = new HardRegion();
		} else if (localName.equals(softTag)) {
			element = Element.SOFT;
			softRegion = new SoftRegion();
		} else {
			if (element == Element.SOFT) {
				softRegion.addString("<" + localName + ">");
			}
		}
	}

	public void endElement(String uri, String localName, String qName)
			throws SAXException {
		if (localName.equals(hardTag)) {
			element = Element.NONE;
			document.addHardRegion(hardRegion);
		} else if (localName.equals(softTag)) {
			element = Element.HARD;
			hardRegion.addSoftRegion(softRegion);
		} else {
			if (element == Element.SOFT) {
				softRegion.addString("</" + localName + ">");
			}
		}
	}

	public void characters(char[] ch, int start, int length)
			throws SAXException {
		if (element == Element.SOFT) {
			String string = new String(ch, start, length);
			if (!string.equals("\n")) {
				/*if (string.indexOf('\n') != -1) {
					System.out.println("'" + string + "'" + length);
					System.out.println(softRegion.getString());
				}*/
				softRegion.addString(string);
			}
		}
	}

	public void ignorableWhitespace(char[] ch, int start, int length)
			throws SAXException {
	}

	public void processingInstruction(String target, String data)
			throws SAXException {
	}

	public void skippedEntity(String name) throws SAXException {
	}
	
	public Document getDocument() {
		return document;
	}
	
	private enum Element{NONE, HARD, SOFT};
	
	private Document document;
	private HardRegion hardRegion;
	private SoftRegion softRegion;
	private String hardTag, softTag; 
	private Element element;
	
}
