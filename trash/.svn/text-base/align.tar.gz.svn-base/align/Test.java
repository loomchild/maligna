import junit.framework.TestSuite;

public class Test extends TestSuite {

	public static junit.framework.Test suite() {		
		TestSuite suite = new TestSuite();

		suite.addTestSuite(ParserTest.class);
		suite.addTestSuite(AlignerTest.class);

		return suite;
	}

}
