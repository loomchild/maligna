import java.util.Vector;

public class DocumentAlignment {

	public DocumentAlignment(Vector<HardRegionAlignment> alignmentTable) {
		hardRegionAlignmentTable = alignmentTable;
	}
	
	public Vector<HardRegionAlignment> getHardRegionAlignmentTable() {
		return hardRegionAlignmentTable;
	}
	
	private Vector<HardRegionAlignment> hardRegionAlignmentTable;

}
