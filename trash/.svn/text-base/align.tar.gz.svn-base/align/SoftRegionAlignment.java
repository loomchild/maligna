import java.util.List;

public class SoftRegionAlignment {

	public SoftRegionAlignment(Category category, 
			HardRegion xHardRegion, HardRegion yHardRegion, 
			int pathX, int pathY, float distance, float totalDistance) {
		this.category = category;
		this.pathX = pathX;
		this.pathY = pathY;
		this.xHardRegion = xHardRegion;
		this.yHardRegion = yHardRegion;
		this.distance = distance;
		this.totalDistance = totalDistance;
	}

	public float getDistance() {
		return distance;
	}
	
	public float getTotalDistance() {
		return totalDistance;
	}
	
	public int getDeltaX() {
		return category.getDeltaX();
	}

	public int getDeltaY() {
		return category.getDeltaY();
	}

	public List<SoftRegion> createXRegionList() {
		return category.createXRegionList(pathX, xHardRegion);
	}

	public List<SoftRegion> createYRegionList() {
		return category.createYRegionList(pathY, yHardRegion);
	}
	
	private HardRegion xHardRegion, yHardRegion;
	private float distance, totalDistance;
	private int pathX, pathY;
	private Category category;
}
