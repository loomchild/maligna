import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class Formatter {
	
	public static Formatter getInstance() {
		return instance;
	}
	
	public void formatXML(DocumentAlignment documentAlignment, 
			String xFileName, String yFileName, 
			String hardTag, String softTag, boolean merge) throws IOException {
		PrintWriter xFile = new PrintWriter(new BufferedWriter(
				new FileWriter(xFileName)), true);
		PrintWriter yFile = new PrintWriter(new BufferedWriter(
				new FileWriter(yFileName)), true);
		xFile.println("<?xml version=\"1.0\" encoding=\"ISO-8859-2\"?>");
		yFile.println("<?xml version=\"1.0\" encoding=\"ISO-8859-2\"?>");
		formatDocument(documentAlignment, xFile, yFile, hardTag, softTag, 
				merge);
	}
	
	public void formatPlain(DocumentAlignment documentAlignment, 
			String xFileName, String yFileName) throws IOException {
		PrintWriter xFile = new PrintWriter(new BufferedWriter(
				new FileWriter(xFileName)), true);
		PrintWriter yFile = new PrintWriter(new BufferedWriter(
				new FileWriter(yFileName)), true);
		for (HardRegionAlignment hardRegionAlignment : 
				documentAlignment.getHardRegionAlignmentTable()) {
			for (SoftRegionAlignment softRegionAlignment : 
					hardRegionAlignment.getSoftRegionAlignmentTable()) {
				for (SoftRegion softRegion : 
						softRegionAlignment.createXRegionList()) {
					xFile.print(softRegion.getString() + ' ');
				}
				xFile.println();
				for (SoftRegion softRegion : 
						softRegionAlignment.createYRegionList()) {
					yFile.print(softRegion.getString() + ' ');
				}
				yFile.println();
			}
		}
	}
	
	public void formatHumanReadable(DocumentAlignment documentAlignment,
			String fileName, int width) throws IOException {
		PrintWriter file = new PrintWriter(new BufferedWriter(
				new FileWriter(fileName)), true);
		int maxLenght = (width - 2) / 2;
		for (HardRegionAlignment hardRegionAlignment : 
				documentAlignment.getHardRegionAlignmentTable()) {
			for (SoftRegionAlignment softRegionAlignment : 
					hardRegionAlignment.getSoftRegionAlignmentTable()) {
				List<String> xStrings = new LinkedList<String>();
				List<String> yStrings = new LinkedList<String>();
				for (SoftRegion softRegion : 
						softRegionAlignment.createXRegionList()) {
					xStrings.addAll(
							splitString(softRegion.getString(),maxLenght));
				}
				for (SoftRegion softRegion : 
						softRegionAlignment.createYRegionList()) {
					yStrings.addAll(
							splitString(softRegion.getString(),maxLenght));
				}
				Iterator<String> xIterator = xStrings.iterator();
				Iterator<String> yIterator = yStrings.iterator();
				while(xIterator.hasNext() && yIterator.hasNext()) {
					String s = formatString(xIterator.next(), 
							yIterator.next(), maxLenght);
					file.println(s);
				}
				while(xIterator.hasNext()) {
					String s = formatString(xIterator.next(), "", maxLenght);
					file.println(s);
				}
				while(yIterator.hasNext()) {
					String s = formatString("", yIterator.next(), maxLenght);
					file.println(s);
				}
				file.println();
			}
			file.println();
		}
	}
	
	private void formatDocument(DocumentAlignment documentAlignment, 
			PrintWriter xFile, PrintWriter yFile, String hardTag, 
			String softTag, boolean merge) {
		for(int hardNr = 0; hardNr < documentAlignment.
				getHardRegionAlignmentTable().size(); ++hardNr) {
			HardRegionAlignment hardRegionAlignment = 
				documentAlignment.getHardRegionAlignmentTable().get(hardNr);
			formatHardRegion(hardRegionAlignment, xFile, yFile, 
					hardTag, softTag, hardNr, merge);
		}
	}
	
	private void formatHardRegion(HardRegionAlignment hardRegionAlignment, 
			PrintWriter xFile, PrintWriter yFile, String hardTag, 
			String softTag, int hardNr, boolean merge) {
		String openingTag = "<" + hardTag + " id=\"" + hardNr + "\">";
		xFile.println(openingTag);
		yFile.println(openingTag);
		for(int softNr = 0; softNr < hardRegionAlignment.
				getSoftRegionAlignmentTable().size(); ++softNr) {
			SoftRegionAlignment softRegionAlignment = 
				hardRegionAlignment.getSoftRegionAlignmentTable().get(softNr);
			formatSoftRegion(softRegionAlignment, xFile, yFile, 
				softTag, softNr, merge);
		}
		String closingTag = "</" + hardTag + ">";
		xFile.println(closingTag);
		yFile.println(closingTag);
	}
	
	private void formatSoftRegion(SoftRegionAlignment softRegionAlignment, 
			PrintWriter xFile, PrintWriter yFile, String softTag, 
			int softNr, boolean merge) {
		String openingTag = "<" + softTag + " id=\"" + softNr + "\">";
		String closingTag = "</" + softTag + ">";
		if (merge) {
			formatMergeSoftRegionList(softRegionAlignment.createXRegionList(), 
					xFile, openingTag, closingTag);
			formatMergeSoftRegionList(softRegionAlignment.createYRegionList(), 
					yFile, openingTag, closingTag);
		} else {
			formatNumberSoftRegionList(softRegionAlignment.createXRegionList(), 
					xFile, openingTag, closingTag);
			formatNumberSoftRegionList(softRegionAlignment.createYRegionList(), 
					yFile, openingTag, closingTag);
		}
	}
	
	private void formatMergeSoftRegionList(List<SoftRegion> regionList, 
			PrintWriter file, String openingTag, String closingTag) {
		file.println(openingTag);
		for (SoftRegion region : regionList) {
			file.println(region.getString());
		}
		file.println(closingTag);
	}
	
	private void formatNumberSoftRegionList(List<SoftRegion> regionList, 
			PrintWriter file, String openingTag, String closingTag) {
		for (SoftRegion region : regionList) {
			file.print(openingTag);
			file.print(region.getString());
			file.print(closingTag);
		}
		file.println();
	}
	
	private List<String> splitString(String string, int maxLength) {
		List<String> stringList = new LinkedList<String>();
		//Proste dzielenie
		int end = maxLength;
		for (; end < string.length(); end += maxLength) {
			stringList.add(string.substring(end - maxLength, end));
		}
		stringList.add(string.substring(end - maxLength));
		return stringList;
	}
	
	private String formatString(String xString, String yString, int maxLength) {
		return expandString(xString, maxLength) + "  " 
				+ expandString(yString, maxLength);
		
	}
	
	private String expandString(String string, int length) {
		if (string.length() < length) {
			StringBuilder builder = new StringBuilder(string);
			builder.setLength(length);
			for (int i = string.length(); i < length; ++i) {
				builder.setCharAt(i, ' ');
			}
			return builder.toString();
		} else {
			return string;
		}
	}

	
	private static Formatter instance = new Formatter();	
	
}
