import java.util.Vector;

public class HardRegion {
	
	public HardRegion() {
		this.softRegionTable = new Vector<SoftRegion>();		
	}
	
	public Vector<SoftRegion> getSoftRegionTable() {
		return softRegionTable;
	}
	
	public void addSoftRegion(SoftRegion softRegion) {
		softRegionTable.add(softRegion);
	}
	
	private Vector<SoftRegion> softRegionTable;
	
}
