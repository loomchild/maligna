package trash;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.xml.sax.SAXException;

public class Main {
	
	public static final String DEFAULT_HARD_TAG = "par";
	public static final String DEFAULT_SOFT_TAG = "zd";
	public static final String FILE_POSTFIX = "_align";

	public static void main(String[] args) {
		try {
			run(args);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private static void run(String[] args) throws IOException, SAXException {

		String hardTag = args[0];
		String softTag = args[1];
		String documentXName = args[2]; 
		String documentYName = args[3];
		String extensionX = extractExtension(documentXName);
		String extensionY = extractExtension(documentYName);
		String alignmentXName = documentXName.substring(0, 
				documentXName.length() - extensionX.length() - 1) 
				+ FILE_POSTFIX + "." + extensionX;
		String alignmentYName = documentYName.substring(0, 
				documentYName.length() - extensionY.length() - 1)
				+ FILE_POSTFIX + "." + extensionY;
		float part = Float.parseFloat(args[6]);
		
		Document documentX = Parser.getInstance().parse(documentXName,
				hardTag, softTag);
		Document documentY = Parser.getInstance().parse(documentYName,
				hardTag, softTag);
		
		DocumentAlignment alignment = 
			Aligner.getInstance().align(documentX, documentY);
		
		
		
		Formatter.getInstance().format(alignment, alignmentXName, 
				alignmentYName, hardTag, softTag);
		
		printStats(alignment);
		
	}
	
	private static String extractExtension(String filePath) {
		int lastDot = filePath.lastIndexOf('.');
		if (lastDot == -1) {
			return "";
		} else {
			return filePath.substring(lastDot + 1);
		}
	}
	
	private static void checkNotExists(String fileName) throws IOException {
		File file = new File(fileName);
		if (file.exists()) {
			throw new IOException("Target file " + fileName + " already exists");
		}
	}
	
	private static void printStats(DocumentAlignment documentAlignment) {
		int nrAlignments = 0;
		Map<String, Integer> stats = new HashMap<String, Integer>();
		for (HardRegionAlignment hardAlignment : 
				documentAlignment.getHardRegionAlignmentTable()) {
			for (SoftRegionAlignment softAlignment : 
					hardAlignment.getSoftRegionAlignmentTable()) {
				++nrAlignments;
				int deltaX = softAlignment.getDeltaX();
				int deltaY = softAlignment.getDeltaY();
				if (deltaX < deltaY) {
					int tmp = deltaX;
					deltaX = deltaY;
					deltaY = tmp;
				}
				String key = deltaX + "-" + deltaY;
				Integer value = stats.get(key);
				int newValue = 1;
				if (value != null) {
					newValue = value + 1;
				}
				stats.put(key, newValue);
			}
		}
		for (Map.Entry<String, Integer> stat : stats.entrySet()) {
			System.out.println(stat.getKey() + ": " 
					+ (float)stat.getValue() / nrAlignments);
		}
	}

}
