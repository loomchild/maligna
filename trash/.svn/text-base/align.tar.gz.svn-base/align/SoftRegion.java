
public class SoftRegion {
	
	public SoftRegion() {
		this.string = "";
	}
	
	public String getString() {
		return string;
	}
	
	public void addString(String string) {
		this.string += string;
	}
	
	public int getLength() { 
		return string.length();
	}
	
	private String string;
	
}
