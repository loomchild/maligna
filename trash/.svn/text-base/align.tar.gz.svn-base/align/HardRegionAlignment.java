import java.util.Vector;

public class HardRegionAlignment {

	public HardRegionAlignment(Vector<SoftRegionAlignment> alignmentTable) {
		softRegionAlignmentTable = alignmentTable;
	}
	
	public Vector<SoftRegionAlignment> getSoftRegionAlignmentTable() {
		return softRegionAlignmentTable;
	}
	
	private Vector<SoftRegionAlignment> softRegionAlignmentTable;
}
