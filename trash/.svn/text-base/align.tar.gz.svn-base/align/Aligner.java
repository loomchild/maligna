import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Vector;

public class Aligner {
	
	public static final float PROBABILITY_1_1 = 0.89f;
	public static final float PROBABILITY_2_2 = 0.011f;
	public static final float PROBABILITY_1_0_OR_0_1 = 0.0099f;
	public static final float PROBABILITY_2_1_OR_1_2 = 0.089f;

	public static Aligner getInstance() {
		return instance;
	}
	
	public DocumentAlignment align(Document xDocument, Document yDocument) {
		if (xDocument.getHardRegionTable().size() != 
				yDocument.getHardRegionTable().size()) {
			throw new IllegalArgumentException("Different amount of hard " +
					"regions in documents: " 
					+ xDocument.getHardRegionTable().size()
					+ " and " +	yDocument.getHardRegionTable().size());
		}
		return alignDocuments(xDocument, yDocument);
	}

	public DocumentAlignment filter(DocumentAlignment documentAlignment, 
			float part) {
		if (part < 0.0 || part > 1.0) {
			throw new IllegalArgumentException("Retained part must be between" +
					"0 and 1 and is " + part);
		}
		float threshold = calculateThreshold(documentAlignment, part);
		return filterDocumentAlignment(documentAlignment, threshold);
	}
	
	private Aligner() {
		initializeCategories();
	}

	private void initializeCategories() {
		categoryList = new LinkedList<Category>();
		categoryList.add(new Category(1, 1, PROBABILITY_1_1));
		categoryList.add(new Category(1, 0, PROBABILITY_1_0_OR_0_1));
		categoryList.add(new Category(0, 1, PROBABILITY_1_0_OR_0_1));
		categoryList.add(new Category(2, 1, PROBABILITY_2_1_OR_1_2));
		categoryList.add(new Category(1, 2, PROBABILITY_2_1_OR_1_2));
		categoryList.add(new Category(2, 2, PROBABILITY_2_2));
	}
	
	private DocumentAlignment alignDocuments(Document xDocument, 
			Document yDocument) {
		Vector<HardRegionAlignment> hardAlignmentTable = 
			new Vector<HardRegionAlignment>(
			xDocument.getHardRegionTable().size());
		for (int hardRegionNr = 0; 
				hardRegionNr < xDocument.getHardRegionTable().size(); 
				++hardRegionNr) {
			HardRegion xHardRegion = 
				xDocument.getHardRegionTable().get(hardRegionNr);
			HardRegion yHardRegion = 
				yDocument.getHardRegionTable().get(hardRegionNr);
			hardAlignmentTable.add(alignHardRegions(xHardRegion, yHardRegion));
		}
		return new DocumentAlignment(hardAlignmentTable);
	}

	private HardRegionAlignment alignHardRegions(HardRegion xRegion, 
			HardRegion yRegion) {
		int xSize = xRegion.getSoftRegionTable().size() + 1;
		int ySize = yRegion.getSoftRegionTable().size() + 1;
		SoftRegionAlignment alignmentTable[][] = 
			new SoftRegionAlignment[xSize][ySize];
		for (int x = 0; x < xSize; ++x) {
			for (int y = 0; y < ySize; ++y) {
				alignmentTable[x][y] = alignSoftRegions(x, y, 
						xRegion, yRegion, alignmentTable);
			}
		}
		int x = xSize - 1;
		int y = ySize - 1;
		List<SoftRegionAlignment> revereseAlignmentList = 
				new LinkedList<SoftRegionAlignment>();
		while ((x > 0) || (y > 0)) {
			SoftRegionAlignment softAlignment = alignmentTable[x][y];
			revereseAlignmentList.add(softAlignment);
			x -= softAlignment.getDeltaX();
			y -= softAlignment.getDeltaY();
		}
		Vector<SoftRegionAlignment> softAlignmentTable = 
			new Vector<SoftRegionAlignment>(revereseAlignmentList.size());
		softAlignmentTable.setSize(revereseAlignmentList.size());
		int alignmentNr = revereseAlignmentList.size() - 1;
		for (SoftRegionAlignment alignment : revereseAlignmentList) {
			softAlignmentTable.set(alignmentNr, alignment);
			--alignmentNr;
		}
		return new HardRegionAlignment(softAlignmentTable);	
	}

	private SoftRegionAlignment alignSoftRegions(int x, int y, 
			HardRegion xRegion, HardRegion yRegion,
			SoftRegionAlignment[][] alignmentTable) {
		float minTotalDistance = Float.POSITIVE_INFINITY;
		float minDistance = Float.POSITIVE_INFINITY;
		Category minCategory = null;
		for (Category category : categoryList) {
			float distance = 
				category.calculateDistance(x, y, xRegion, yRegion);
			float totalDistance = distance + 
				category.calculatePreviousDistance(x, y, alignmentTable);
			if (minTotalDistance > totalDistance) {
				minTotalDistance = totalDistance;
				minDistance = distance;
				minCategory = category;
			}
		}
		if (minDistance == Float.POSITIVE_INFINITY) {
			return new SoftRegionAlignment(null, null, null, 0, 0, 0.0f, 0.0f);
		} else {
			return new SoftRegionAlignment(minCategory, 
					xRegion, yRegion, x, y, minDistance, minTotalDistance);
		}
	}
	
	private float calculateThreshold(DocumentAlignment documentAlignment, 
			float part) {
		Vector<Float> distanceTable = new Vector<Float>();
		for (HardRegionAlignment hardRegionAlignment : 
				documentAlignment.getHardRegionAlignmentTable()) {
			for (SoftRegionAlignment softRegionAlignment : 
					hardRegionAlignment.getSoftRegionAlignmentTable()) {
				distanceTable.add(softRegionAlignment.getDistance());
			}
		}
		Collections.sort(distanceTable);
		int index = (int)(part * (float)distanceTable.size() + 0.5) - 1;
		if (index < 0) {
			return Float.NEGATIVE_INFINITY;
		}
		return distanceTable.get(index);
	}
	
	private DocumentAlignment filterDocumentAlignment(
			DocumentAlignment documentAlignment, float threshold) {
		Vector<HardRegionAlignment> hardAlignmentTable = 
			new Vector<HardRegionAlignment>(); 
		for (HardRegionAlignment hardRegionAlignment : 
			documentAlignment.getHardRegionAlignmentTable()) {
			Vector<SoftRegionAlignment> softAlignmentTable = 
				new Vector<SoftRegionAlignment>(); 
			for (SoftRegionAlignment softRegionAlignment : 
				hardRegionAlignment.getSoftRegionAlignmentTable()) {
				if (softRegionAlignment.getDistance() <= threshold) {
					softAlignmentTable.add(softRegionAlignment);
				}
			}
			hardAlignmentTable.add(new HardRegionAlignment(softAlignmentTable));
		}
		return new DocumentAlignment(hardAlignmentTable);
	}
	
	private static Aligner instance = new Aligner();
	
	private List<Category> categoryList;
	
}
