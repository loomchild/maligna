import java.io.IOException;

import junit.framework.TestCase;

import org.xml.sax.SAXException;

public class ParserTest extends TestCase {

	public static final String HARD_TAG = "ak";
	public static final String SOFT_TAG = "zd";
	public static final String DOCUMENT = "documentx.xml";
	
	public ParserTest() {
		parser = Parser.getInstance();
	}
	
	public void testParse() {
		Document document = null;
		try {
			document = parser.parse(DOCUMENT, HARD_TAG, SOFT_TAG);
		} catch (SAXException e) {
			fail("Parser error parsing correct document: " + e.getMessage());
		} catch (IOException e) {
			fail("IO error parsing correct document: " + e.getMessage());
		}
		assertEquals(2,document.getHardRegionTable().size());
		HardRegion hardRegion0 = document.getHardRegionTable().get(0);
		assertEquals(2,hardRegion0.getSoftRegionTable().size());
		SoftRegion softRegion00 = hardRegion0.getSoftRegionTable().get(0);
		assertEquals("To zdanie",softRegion00.getString());
		SoftRegion softRegion01 = hardRegion0.getSoftRegionTable().get(1);
		assertEquals("to <ignorowany>aaa</ignorowany>drugie",
				softRegion01.getString());
		HardRegion hardRegion1 = document.getHardRegionTable().get(1);
		assertEquals(1,hardRegion1.getSoftRegionTable().size());
		SoftRegion softRegion10 = hardRegion1.getSoftRegionTable().get(0);
		assertEquals("jeszcze",softRegion10.getString());
	}
	
	private Parser parser;
	
}
