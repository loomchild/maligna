import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.xml.sax.SAXException;

/**
 * Prgram do zr�wnoleglania.
 * Dane wej�ciowe:
 * 1 plik tekstowy
 * 2 plik tesktowy
 * twardy tag
 * mi�kki tag
 * ile tekstu wej�ciowe ma zosta� zachowane na wyj�ciu <0,1> Mo�na odrzuci� cz�� by 
 * uzyska� lepsze zr�wnoleglenie
 * format wyj�cia {
 * 		merge	po��cz zr�wnoleglone regiony i wyj�cie w XML
 * 		number	ponumeruj zr�wnoleglone regiony, o tym samym numerze r�wnoleg�e, wyj�cie w XML
 * 		plain	zwyk�e pliki tekstowe, maj� te sam� ilo�� linii
 * 		human	1 plik w formacie czytalnym dla cz�owieka
 * Na wyj�ciu generowany jest plik z opdowiednim rozszerzeniem 
 * z prefixem align-<nazwa_mi�kkiego_regionu>_. 
 * @author loomchild
 */
public class Main {
	
	enum Output {merge, number, plain, human};
	
	public static void main(String[] args) {
		try {
			if (args.length < 6) {
				System.out.println("Zle parametry");
			} else {
				run(args);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private static void run(String[] args) throws IOException, SAXException {

		String documentXName = args[0]; 
		String documentYName = args[1];
		String hardTag = args[2];
		String softTag = args[3];
		float part = Float.parseFloat(args[4]);
		Output output;
		if (args[5].equals("merge")) {
			output = Output.merge;
		} else if (args[5].equals("number")) {
			output = Output.number;
		} else if (args[5].equals("plain")) {
			output = Output.plain;
		}  else if (args[5].equals("human")) {
			output = Output.human;
		} else {
			throw new IllegalArgumentException("Must be plain or merge or number");
		}
		
		boolean plain = ((output == Output.plain) || (output == Output.human));  
		String alignmentXName = formatAlignmentName(documentXName, 
				softTag, plain);
		String alignmentYName = formatAlignmentName(documentYName, 
				softTag, plain);
	
		Document documentX = Parser.getInstance().parse(documentXName,
				hardTag, softTag);
		Document documentY = Parser.getInstance().parse(documentYName,
				hardTag, softTag);
		
		DocumentAlignment alignment = 
			Aligner.getInstance().align(documentX, documentY);
		
		alignment = Aligner.getInstance().filter(alignment, part);
		
		if (output == Output.plain) {
			Formatter.getInstance().formatPlain(alignment, alignmentXName, 
					alignmentYName);
		} else if (output == Output.merge) {
			Formatter.getInstance().formatXML(alignment, alignmentXName, 
				alignmentYName, hardTag, softTag, true);
		} else if (output == Output.number) {
			Formatter.getInstance().formatXML(alignment, alignmentXName, 
					alignmentYName, hardTag, softTag, false);
		} else {
			Formatter.getInstance().formatHumanReadable(alignment, 
					alignmentXName, 80);
		}
		
		printStats(alignment);
		
	}
	
	private static String formatAlignmentName(String documentName, 
			String softTag, boolean plain) {
		String documentExtension = extractExtension(documentName);
		String name = documentName.substring(0, documentName.length() - 
				documentExtension.length() - 1);
		name = "align-" + softTag + "_" + name;
		if (plain) {
			name += ".txt";
		} else {
			name += ".xml";
		}
		return name;
	}
	
	private static String extractExtension(String filePath) {
		int lastDot = filePath.lastIndexOf('.');
		if (lastDot == -1) {
			return "";
		} else {
			return filePath.substring(lastDot + 1);
		}
	}

	private static void printStats(DocumentAlignment documentAlignment) {
		int nrAlignments = 0;
		Map<String, Integer> stats = new HashMap<String, Integer>();
		for (HardRegionAlignment hardAlignment : 
				documentAlignment.getHardRegionAlignmentTable()) {
			for (SoftRegionAlignment softAlignment : 
					hardAlignment.getSoftRegionAlignmentTable()) {
				++nrAlignments;
				int deltaX = softAlignment.getDeltaX();
				int deltaY = softAlignment.getDeltaY();
				if (deltaX < deltaY) {
					int tmp = deltaX;
					deltaX = deltaY;
					deltaY = tmp;
				}
				String key = deltaX + "-" + deltaY;
				Integer value = stats.get(key);
				int newValue = 1;
				if (value != null) {
					newValue = value + 1;
				}
				stats.put(key, newValue);
			}
		}
		for (Map.Entry<String, Integer> stat : stats.entrySet()) {
			System.out.println(stat.getKey() + ": " 
					+ (float)stat.getValue() / nrAlignments);
		}
	}

}
